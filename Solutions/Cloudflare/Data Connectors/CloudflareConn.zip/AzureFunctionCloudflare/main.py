# This is function version 2.0.0 supporting python > 3.9

import os
import asyncio
from azure.storage.blob.aio import ContainerClient
import json
import logging
import azure.functions as func
import re
import time
import aiohttp
from json import JSONDecodeError
import traceback
import datetime
import logging
import json
import hashlib
import hmac
import base64
import aiohttp
import asyncio
from collections import deque


class AzureSentinelConnectorAsync:
    def __init__(self, session: aiohttp.ClientSession, log_analytics_uri, workspace_id, shared_key, log_type, queue_size=1000, queue_size_bytes=25 * (2**20)):
        self.log_analytics_uri = log_analytics_uri
        self.workspace_id = workspace_id
        self.shared_key = shared_key
        self.log_type = log_type
        self.queue_size = queue_size
        self.queue_size_bytes = queue_size_bytes
        self._queue = deque()
        self.successfull_sent_events_number = 0
        self.failed_sent_events_number = 0
        self.lock = asyncio.Lock()
        self.session = session

    async def send(self, event):
        events = None
        async with self.lock:
            self._queue.append(event)
            if len(self._queue) >= self.queue_size:
                events = list(self._queue)
                self._queue.clear()
        if events:
            await self._flush(events)

    async def flush(self):
        await self._flush(list(self._queue))

    async def _flush(self, data: list):
        if data:
            data = self._split_big_request(data)
            await asyncio.gather(*[self._post_data(self.session, self.workspace_id, self.shared_key, d, self.log_type) for d in data])

    def _build_signature(self, workspace_id, shared_key, date, content_length, method, content_type, resource):
        x_headers = 'x-ms-date:' + date
        string_to_hash = method + "\n" + str(content_length) + "\n" + content_type + "\n" + x_headers + "\n" + resource
        bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
        decoded_key = base64.b64decode(shared_key)
        encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
        authorization = "SharedKey {}:{}".format(workspace_id, encoded_hash)
        return authorization

    async def _post_data(self, session: aiohttp.ClientSession, workspace_id, shared_key, body, log_type):
        logging.debug('Start sending data to sentinel')
        events_number = len(body)
        body = json.dumps(body)
        method = 'POST'
        content_type = 'application/json'
        resource = '/api/logs'
        rfc1123date = datetime.datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
        content_length = len(body)
        signature = self._build_signature(workspace_id, shared_key, rfc1123date, content_length, method, content_type, resource)
        uri = self.log_analytics_uri + resource + '?api-version=2016-04-01'

        headers = {
            'content-type': content_type,
            'Authorization': signature,
            'Log-Type': log_type,
            'x-ms-date': rfc1123date
        }

        try_number = 1
        while True:
            try:
                await self._make_request(session, uri, body, headers)
            except Exception as err:
                if try_number < 3:
                    logging.warning('Error while sending data to Azure Sentinel. Try number: {}. Trying one more time. {}'.format(try_number, err))
                    await asyncio.sleep(try_number)
                    try_number += 1
                else:
                    logging.error(str(err))
                    self.failed_sent_events_number += events_number
                    raise err
            else:
                logging.debug('{} events have been successfully sent to Azure Sentinel'.format(events_number))
                self.successfull_sent_events_number += events_number
                break


    async def _make_request(self, session, uri, body, headers):
        async with session.post(uri, data=body, headers=headers) as response:
            await response.text()
            if not (200 <= response.status <= 299):
                raise Exception("Error during sending events to Azure Sentinel. Response code: {}".format(response.status))

    def _check_size(self, queue):
        data_bytes_len = len(json.dumps(queue).encode())
        return data_bytes_len < self.queue_size_bytes

    def _split_big_request(self, queue):
        if self._check_size(queue):
            return [queue]
        else:
            middle = int(len(queue) / 2)
            queues_list = [queue[:middle], queue[middle:]]
            return self._split_big_request(queues_list[0]) + self._split_big_request(queues_list[1])



logging.getLogger(
    'azure.core.pipeline.policies.http_logging_policy').setLevel(logging.ERROR)
logging.getLogger('charset_normalizer').setLevel(logging.ERROR)



MAX_SCRIPT_EXEC_TIME_MINUTES = 5


AZURE_STORAGE_CONNECTION_STRING = os.environ['AZURE_STORAGE_CONNECTION_STRING']
CONTAINER_NAME = os.environ['CONTAINER_NAME']
WORKSPACE_ID = os.environ['WORKSPACE_ID']
SHARED_KEY = os.environ['SHARED_KEY']
WORKSPACE_ID_2 = os.environ['WORKSPACE_ID_2']
SHARED_KEY_2 = os.environ['SHARED_KEY_2']
LOG_TYPE = 'Cloudflare'
LINE_SEPARATOR = os.environ.get(
    'lineSeparator',  '[\n\r\x0b\v\x0c\f\x1c\x1d\x85\x1e\u2028\u2029]+')

# Defines how many files can be processed simultaneously
MAX_CONCURRENT_PROCESSING_FILES = int(
    os.environ.get('MAX_CONCURRENT_PROCESSING_FILES', 10))

# Defines page size while listing files from blob storage. New page is not processed while old page is processing.
MAX_PAGE_SIZE = int(MAX_CONCURRENT_PROCESSING_FILES * 20)

# Defines max number of events that can be sent in one request to Azure Sentinel
MAX_BUCKET_SIZE = int(os.environ.get('MAX_BUCKET_SIZE', 2000))

# Defines max chunk download size for blob storage in MB
MAX_CHUNK_SIZE_MB = int(os.environ.get('MAX_CHUNK_SIZE_MB', 1))

LOG_ANALYTICS_URI = os.environ.get('logAnalyticsUri')
LOG_ANALYTICS_URI_2 = os.environ.get('logAnalyticsUri2')

if not LOG_ANALYTICS_URI or str(LOG_ANALYTICS_URI).isspace():
    LOG_ANALYTICS_URI = 'https://' + WORKSPACE_ID + '.ods.opinsights.azure.com'
if not LOG_ANALYTICS_URI_2 or str(LOG_ANALYTICS_URI_2).isspace():
    LOG_ANALYTICS_URI_2 = 'https://' + WORKSPACE_ID_2 + '.ods.opinsights.azure.com'


pattern = r'https:\/\/([\w\-]+)\.ods\.opinsights\.azure.([a-zA-Z\.]+)$'
match = re.match(pattern, str(LOG_ANALYTICS_URI))
if not match:
    raise Exception("Invalid Log Analytics Uri.")
pattern = r'https:\/\/([\w\-]+)\.ods\.opinsights\.azure.([a-zA-Z\.]+)$'
if not re.match(pattern, str(LOG_ANALYTICS_URI_2)):
    raise Exception("Invalid Log Analytics URI for the second workspace.")



async def main(mytimer: func.TimerRequest):
    try:
        logging.info('Starting script')
        logging.info('Concurrency parameters: MAX_CONCURRENT_PROCESSING_FILES {}, MAX_PAGE_SIZE {}, MAX_BUCKET_SIZE {}.'.format(
            MAX_CONCURRENT_PROCESSING_FILES, MAX_PAGE_SIZE, MAX_BUCKET_SIZE))
        conn = AzureBlobStorageConnector(
            AZURE_STORAGE_CONNECTION_STRING, CONTAINER_NAME, MAX_CONCURRENT_PROCESSING_FILES)
        container_client = conn._create_container_client()
        async with container_client:
            async with aiohttp.ClientSession() as session:
                cors = []
                async for blob in conn.get_blobs():
                    try:
                        cor = conn.process_blob(blob, container_client, session)
                        cors.append(cor)
                    except Exception as e:
                        logging.error(f'Exception in processing blob is {e}')
                    if len(cors) >= MAX_PAGE_SIZE:
                        await asyncio.gather(*cors)
                        cors = []
                    if conn.check_if_script_runs_too_long():
                        logging.info(
                            'Script is running too long. Stop processing new blobs.')
                        break

                if cors:
                    await asyncio.gather(*cors)
                    logging.info('Processed {} files with {} events.'.format(
                        conn.total_blobs, conn.total_events))

        logging.info('Script finished. Processed files: {}. Processed events: {}'.format(
            conn.total_blobs, conn.total_events))
    except Exception as ex:
        logging.error('An error occurred in the main script: {}'.format(str(ex)))
        logging.error(traceback.format_exc())


class AzureBlobStorageConnector:
    def __init__(self, conn_string, container_name, max_concurrent_processing_fiiles=10):
        self.__conn_string = conn_string
        self.__container_name = container_name
        self.semaphore = asyncio.Semaphore(max_concurrent_processing_fiiles)
        self.script_start_time = int(time.time())
        self.total_blobs = 0
        self.total_events = 0   

    def _create_container_client(self):
        try:
            return ContainerClient.from_connection_string(self.__conn_string, self.__container_name, logging_enable=False, max_single_get_size=MAX_CHUNK_SIZE_MB*1024*1024, max_chunk_get_size=MAX_CHUNK_SIZE_MB*1024*1024)
        except Exception as ex:
            logging.error('An error occurred in _create_container_client: {}'.format(str(ex)))
            logging.error(traceback.format_exc())
            return None        
        
    async def get_blobs(self):
        try:
            container_client = self._create_container_client()
            logging.info("inside get_blobs function")
            async with container_client:
                async for blob in container_client.list_blobs():
                    if 'ownership-challenge' not in blob['name']:
                        yield blob
        except Exception as ex:
            logging.error(f'An error occurred in get_blobs: {ex}')
            logging.error(traceback.format_exc())

    def check_if_script_runs_too_long(self):
        now = int(time.time())
        duration = now - self.script_start_time
        max_duration = int(MAX_SCRIPT_EXEC_TIME_MINUTES * 60 * 0.85)
        return duration > max_duration
    

    async def delete_blob(self, blob, container_client):
        try:
            logging.info("inside delete_blob function...")
            logging.info("Deleting blob {}".format(blob['name']))
            await container_client.delete_blob(blob['name'])
        except Exception as ex:
            logging.error(f'An error occurred while deleting blob {blob["name"]}: {ex}')
            logging.error(traceback.format_exc())

    async def process_blob(self, blob, container_client, session: aiohttp.ClientSession):
        try:
            async with self.semaphore:
                logging.info("Start processing {}".format(blob['name']))
                try:
                    sentinel = AzureSentinelConnectorAsync(
                        session, LOG_ANALYTICS_URI, WORKSPACE_ID, SHARED_KEY, LOG_TYPE, queue_size=MAX_BUCKET_SIZE)
                    sentinel_2 = AzureSentinelConnectorAsync(
                    session, LOG_ANALYTICS_URI_2, WORKSPACE_ID_2, SHARED_KEY_2, LOG_TYPE, queue_size=MAX_BUCKET_SIZE)
                    blob_cor = await container_client.download_blob(blob['name'], encoding="utf-8")

                except Exception as e:
                    logging.error(f'error while connecting to Sentinel: {e}')
                    logging.error(traceback.format_exc())
                s = ''
                async for chunk in blob_cor.chunks():
                    s += chunk.decode()
                    lines = re.split(r'{0}'.format(LINE_SEPARATOR), s)
                    for n, line in enumerate(lines):
                        if n < len(lines) - 1:
                            if line:
                                try:
                                    event = json.loads(line)
                                except JSONDecodeError as je:
                                    logging.error('JSONDecode error while loading json event at line value {}. blob name: {}. Error {}'.format(
                                        line, blob['name'], str(je)))
                                    raise je
                                except ValueError as e:
                                    logging.error('Error while loading json Event at line value {}. blob name: {}. Error: {}'.format(
                                        line, blob['name'], str(e)))
                                    raise e
                                await sentinel.send(event)
                                await sentinel_2.send(event)
                        s = line
                if s:
                    try:
                        event = json.loads(s)
                    except JSONDecodeError as je:
                        logging.error('JSONDecode error while loading json event at line value {}. blob name: {}. Error {}'.format(
                            line, blob['name'], str(je)))
                        raise je
                    except ValueError as e:
                        logging.error('Error while loading json Event at s value {}. blob name: {}. Error: {}'.format(
                            line, blob['name'], str(e)))
                        raise e
                    await sentinel.send(event)
                    await sentinel_2.send(event)
                await sentinel.flush()
                await sentinel_2.flush()
                await self.delete_blob(blob, container_client)
                self.total_blobs += 1
                self.total_events += sentinel.successfull_sent_events_number
                logging.info("Finish processing {}. Sent events: {}".format(
                    blob['name'], sentinel.successfull_sent_events_number))
                if self.total_blobs % 100 == 0:
                    logging.info('Processed {} files with {} events.'.format(
                        self.total_blobs, self.total_events))
                    
        except Exception as ex:
            logging.error(f"Error in process_blob is {ex}")

